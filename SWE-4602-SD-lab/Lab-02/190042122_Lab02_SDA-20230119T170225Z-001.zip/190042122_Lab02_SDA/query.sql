ALTER TABLE vote 
RENAME TO  rating;