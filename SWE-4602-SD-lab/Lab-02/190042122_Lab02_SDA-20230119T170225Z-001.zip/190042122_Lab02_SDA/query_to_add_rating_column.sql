ALTER TABLE product
ADD COLUMN average_rating int not null default 0;

ALTER TABLE rating
ADD COLUMN rating int default 0;