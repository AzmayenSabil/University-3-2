package Main;

public class Conversion {
    public double feetToMeters(double feet) {
        return feet * 0.3048;
    }

    public double metersToFeet(double meters) {
        return meters / 0.3048;
    }
}
