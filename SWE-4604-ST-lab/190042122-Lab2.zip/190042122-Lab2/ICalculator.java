package Main;

public interface ICalculator {
    double add();
    double subtract();
    double multiply();
    double divide();
}