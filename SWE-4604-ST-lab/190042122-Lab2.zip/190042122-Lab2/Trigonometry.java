package Main;

public class Trigonometry {
    public double sine(double angle) {
        return Math.sin(angle);
    }

    public double cosine(double angle) {
        return Math.cos(angle);
    }

    public double tangent(double angle) {
        return Math.tan(angle);
    }
}
