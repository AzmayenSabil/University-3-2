import React, { useState } from "react" ;
import './App.css';
import FormInput from './components/FormInput';

function App() {
  const [values, setValues] = useState({
    movieName:"",
    movieReview:""
  })

  const inputs = [
    {
      id:1,
      name:"movieName",
      type:"text",
      placeholder:"Movie Name",
      errorMessage: "Movie Name Shouldn't be empty.",
      label:"Movie Name",
      pattern: "^[A-Za-z0-9]{1,20}$",
      required: true
    },
    {
      id:2,
      name: "movieReview",
      type:"text",
      placeholder:"Movie Review",
      errorMessage: "Movie Review should be 20-300 characters",
      pattern: "^[A-Za-z]{20,300}$",
      label:"Movie Review",
      required: true
    }
  ]

  const onChange = (e) => {
    setValues({...values, [e.target.name]:e.target.value});
  }
  console.log(values);
  return (
    <div className="App">
      
        <form>
          {inputs.map((input) =>(
            <FormInput key={input.id} {...input} value={values[input.name]} onChange = {onChange}/>
          ))}
          <button>Submit</button>
        </form>
    </div>
  );
}

export default App;
